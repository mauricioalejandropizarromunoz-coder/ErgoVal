# Plan de figuras

**Regla general:** cada imagen muestra como máximo **2 cuerpos**. Si una figura necesita más posturas, se divide en varias imágenes (a, b, c…) dentro de la misma figura. Tamaños: **2 cuerpos = 800×520 px**, **1 cuerpo = 480×640 px**, diagramas según la tabla. PNG para esquemas, JPG (calidad 80) para fotos; menos de 120 KB cada una.

Para reemplazar un marcador, guardar la imagen real con **el mismo nombre** dentro de `images/`.

| Figura | Contenido | Cuerpos | Archivos |
|---|---|---|---|
| 1.1 | Esquema de reducción del riesgo mediante el rediseño de puestos. | diagrama | fig-1-01.png |
| 4.1 | Medición de ángulo incorrecta frente a una medición correcta (en verdadera magnitud). | 2 | fig-4-01.png |
| 4.2 | División del cuerpo en el lado derecho y el lado izquierdo por el plano sagital. | 1 | fig-4-02.png |
| 4.3 | Grupos de evaluación en el método RULA. | 1 | fig-4-03.png |
| 4.4 | Posiciones del brazo. | 4 | fig-4-04a.png, fig-4-04b.png |
| 4.5 | Eje de referencia para la medición del ángulo de los brazos. | 1 | fig-4-05.png |
| 4.6 | Modificaciones sobre la puntuación del brazo. | 3 | fig-4-06a.png, fig-4-06b.png |
| 4.7 | Posiciones del antebrazo. | 2 | fig-4-07.png |
| 4.8 | Referencia para la medición del ángulo del antebrazo. | 1 | fig-4-08.png |
| 4.9 | Posiciones que modifican la puntuación del antebrazo. | 2 | fig-4-09.png |
| 4.10 | Posiciones de la muñeca. | 3 | fig-4-10a.png, fig-4-10b.png |
| 4.11 | Modificación de la puntuación de la muñeca, en función de la desviación. | 2 | fig-4-11.png |
| 4.12 | Giro de la muñeca. | 2 | fig-4-12.png |
| 4.13 | Posiciones del cuello. | 4 | fig-4-13a.png, fig-4-13b.png |
| 4.14 | Posiciones que modifican la puntuación del cuello. | 2 | fig-4-14.png |
| 4.15 | Posiciones del tronco. | 4 | fig-4-15a.png, fig-4-15b.png |
| 4.16 | Posiciones que modifican la puntuación del tronco. | 2 | fig-4-16.png |
| 4.17 | Posiciones de las piernas. | 2 | fig-4-17.png |
| 4.18 | Procedimiento de aplicación del método RULA. | diagrama | fig-4-18.png |
| 4.19 | Posiciones del tronco en el método REBA. | 4 | fig-4-19a.png, fig-4-19b.png |
| 4.20 | Posiciones del cuello en el método REBA. | 2 | fig-4-20.png |
| 4.21 | Posiciones de las piernas en el método REBA. | 4 | fig-4-21a.png, fig-4-21b.png |
| 4.22 | Posiciones del brazo en el método REBA. | 4 | fig-4-22a.png, fig-4-22b.png |
| 4.23 | Posiciones del antebrazo en el método REBA. | 2 | fig-4-23.png |
| 4.24 | Posiciones de la muñeca en el método REBA. | 2 | fig-4-24.png |
| 4.25 | Procedimiento de aplicación del método REBA. | diagrama | fig-4-25.png |
| 4.26 | Ejemplo de registro de observaciones del método OWAS. | diagrama | fig-4-26.png |
| 4.27 | Posiciones de la espalda en el método OWAS. | 4 | fig-4-27a.png, fig-4-27b.png |
| 4.28 | Posiciones de los brazos en el método OWAS. | 3 | fig-4-28a.png, fig-4-28b.png |
| 4.29 | Posiciones de las piernas en el método OWAS. | 7 | fig-4-29a.png, fig-4-29b.png, fig-4-29c.png, fig-4-29d.png |
| 4.30 | Magnitud de la carga en el método OWAS. | diagrama | fig-4-30.png |
