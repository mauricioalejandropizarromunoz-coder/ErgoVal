#!/bin/sh
# Genera el EPUB a partir de libro.html (las imágenes van en la carpeta images/)
pandoc libro.html -f html -t epub3 -o libro.epub \
  --metadata-file=metadata.yaml --css=estilo.css \
  --toc --toc-depth=3 --split-level=2 --resource-path=.
